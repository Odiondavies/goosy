class Config(object):
    MERCHANT_KEY = '1w456'


class DevelopmentConfig(Config):
    MERCHANT_KEY = 'asd%th455^&*(AG78'
