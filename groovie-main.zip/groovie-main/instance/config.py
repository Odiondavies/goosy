ADMIN_EMAIL = 'joachim@gmail.com'
APP_NAME = 'grooveApp'
DEBUG = True
ENV = 'development'
SECRET_KEY = 'iam/number4&'
SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://root@localhost/groovekitchendb'
SQLALCHEMY_TRACK_MODIFICATIONS = True
